import type { Mock } from 'vitest';
import {
  Agent,
  ConversationExecutionStatus,
  ConversationManager,
  HttpClient,
  HttpError,
  isAskUserAnswerEvent,
  isMessageEditEvent,
  isReactionEvent,
  RemoteConversation,
  RemoteEventsList,
  RemoteWorkspace,
  Workspace,
} from '../index';
import {
  ACPClient,
  AgentProfilesClient,
  AgentServerClient,
  AgentServerVersionError,
  BashClient,
  clearAgentServerInfoCache,
  CloudClient,
  compareAgentServerVersions,
  ConversationClient,
  DeviceFlowError,
  FileClient,
  GitClient,
  HooksClient,
  isAgentServerVersionError,
  isOpenHandsCloudHost,
  LLMMetadataClient,
  MCPClient,
  MetaProfilesClient,
  PluginsClient,
  ProfilesClient,
  ServerClient,
  SettingsClient,
  SharedClient,
  SkillsClient,
  SubAgentsClient,
  ToolClient,
  WorkspacesClient,
} from '../clients';
import * as http from 'node:http';
import { EventEmitter } from 'node:events';

// `fetch` rejects a GET body, so the batch endpoints route through node:http.
// Its `request` export isn't configurable (vi.spyOn fails), so mock the module.
vi.mock('node:http', async (importOriginal) => ({
  ...(await importOriginal<typeof import('node:http')>()),
  request: vi.fn(),
}));

const originalFetch = global.fetch;

/**
 * Drive the mocked Node `http.request` for the GET-with-body transport path used
 * by the batch endpoints. Captures the request URL/options/body and replays a
 * canned JSON response.
 */
function mockNodeHttpRequest(responseBody: string, status = 200) {
  const captured: { url?: URL; options?: http.RequestOptions; body?: string } = {};
  (http.request as Mock).mockImplementation((url: unknown, options: unknown, cb: unknown) => {
    captured.url = url as URL;
    captured.options = options as http.RequestOptions;
    const callback = cb as (res: http.IncomingMessage) => void;
    const req = new EventEmitter() as unknown as http.ClientRequest;
    (req as unknown as { setTimeout: unknown }).setTimeout = vi.fn();
    (req as unknown as { destroy: unknown }).destroy = vi.fn();
    (req as unknown as { end: unknown }).end = vi.fn((body?: string) => {
      captured.body = body;
      process.nextTick(() => {
        const res = new EventEmitter() as unknown as http.IncomingMessage;
        res.statusCode = status;
        res.statusMessage = status === 200 ? 'OK' : 'Error';
        res.headers = { 'content-type': 'application/json' };
        callback(res);
        res.emit('data', Buffer.from(responseBody));
        res.emit('end');
      });
    });
    return req;
  });
  return { captured };
}

describe('Auxiliary API clients', () => {
  afterEach(() => {
    global.fetch = originalFetch;
    clearAgentServerInfoCache();
    vi.restoreAllMocks();
  });

  it('ConversationManager exposes server and skills namespaces', () => {
    const manager = new ConversationManager({ host: 'http://example.com', apiKey: 'secret' });

    expect(manager.server).toBeInstanceOf(ServerClient);
    expect(manager.skills).toBeInstanceOf(SkillsClient);
    expect(manager.subAgents).toBeInstanceOf(SubAgentsClient);
    expect(manager.profiles).toBeInstanceOf(ProfilesClient);
    expect(manager.agentProfiles).toBeInstanceOf(AgentProfilesClient);
    expect(manager.metaProfiles).toBeInstanceOf(MetaProfilesClient);
    expect(manager.server.host).toBe('http://example.com');
    expect(manager.server.apiKey).toBe('secret');
    expect(manager.profiles.host).toBe('http://example.com');
    expect(manager.profiles.apiKey).toBe('secret');
    expect(manager.agentProfiles.host).toBe('http://example.com');
    expect(manager.agentProfiles.apiKey).toBe('secret');
    expect(manager.metaProfiles.host).toBe('http://example.com');
    expect(manager.metaProfiles.apiKey).toBe('secret');
    expect(manager.files).toBeInstanceOf(FileClient);
    expect(manager.workspaces).toBeInstanceOf(WorkspacesClient);
    expect(manager.shared).toBeInstanceOf(SharedClient);
    expect(manager.hooks).toBeInstanceOf(HooksClient);
    expect(manager.mcp).toBeInstanceOf(MCPClient);
  });

  describe('Aggregate clients', () => {
    it('AgentServerClient preserves the existing endpoint clients behind namespaces', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ status: 'ok' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentServerClient({ host: 'http://example.com/', apiKey: 'secret' });

      expect(client.kind).toBe('agent-server');
      expect(client.server).toBeInstanceOf(ServerClient);
      expect(client.conversations).toBeInstanceOf(ConversationClient);
      expect(client.settings).toBeInstanceOf(SettingsClient);
      expect(client.git).toBeInstanceOf(GitClient);
      expect(client.host).toBe('http://example.com');

      await client.request({ method: 'GET', path: '/health' });

      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/health',
        expect.objectContaining({
          method: 'GET',
          headers: expect.objectContaining({
            'X-Session-API-Key': 'secret',
          }),
        })
      );
    });

    it('CloudClient sends bearer auth and X-Org-Id for cloud app-host requests', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ items: [], current_org_id: 'org-1' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new CloudClient({
        host: 'https://app.all-hands.dev/',
        apiKey: 'cloud-key',
        orgId: 'org-1',
      });
      const result = await client.getOrganizations();

      expect(result).toEqual({ items: [], currentOrgId: 'org-1' });
      expect(global.fetch).toHaveBeenCalledWith(
        'https://app.all-hands.dev/api/organizations',
        expect.objectContaining({
          method: 'GET',
          headers: expect.objectContaining({
            Authorization: 'Bearer cloud-key',
            'X-Org-Id': 'org-1',
          }),
        })
      );
    });

    it('CloudClient routes hostOverride requests through the configured proxy', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new CloudClient({
        host: 'https://app.all-hands.dev',
        apiKey: 'cloud-key',
        proxy: {
          host: 'http://localhost:8001',
          apiKey: 'local-key',
        },
      });

      await client.request({
        method: 'POST',
        hostOverride: 'https://runtime.example.com',
        path: '/api/conversations/c1/events',
        body: { role: 'user' },
        authMode: 'session-api-key',
        sessionApiKey: 'runtime-key',
      });

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8001/api/cloud-proxy',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'X-Session-API-Key': 'local-key',
          }),
        })
      );
      const body = JSON.parse((global.fetch as Mock).mock.calls[0][1].body as string);
      expect(body).toEqual({
        host: 'https://runtime.example.com',
        method: 'POST',
        path: '/api/conversations/c1/events',
        headers: { 'X-Session-API-Key': 'runtime-key' },
        body: { role: 'user' },
      });
    });

    it('CloudClient forwards app-conversation observability fields', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            id: 'task-1',
            created_by_user_id: null,
            status: 'WORKING',
            detail: null,
            app_conversation_id: null,
            agent_server_url: null,
            request: {},
            created_at: '2026-07-30T00:00:00Z',
            updated_at: '2026-07-30T00:00:00Z',
          }),
          {
            status: 200,
            headers: { 'content-type': 'application/json' },
          }
        )
      ) as typeof fetch;

      const client = new CloudClient({
        host: 'https://app.all-hands.dev',
        apiKey: 'cloud-key',
      });

      await client.createConversation({
        initial_message: null,
        observability_span_name: 'mySpanName',
        observability_tags: ['wb-rubric', 'recall'],
        observability_metadata: {
          evaluation: 'wb',
          attempt: 1,
          replay: false,
        },
      });

      expect(global.fetch).toHaveBeenCalledWith(
        'https://app.all-hands.dev/api/v1/app-conversations',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            Authorization: 'Bearer cloud-key',
          }),
        })
      );
      const body = JSON.parse((global.fetch as Mock).mock.calls[0][1].body as string);
      expect(body).toMatchObject({
        initial_message: null,
        observability_span_name: 'mySpanName',
        observability_tags: ['wb-rubric', 'recall'],
        observability_metadata: {
          evaluation: 'wb',
          attempt: 1,
          replay: false,
        },
      });
    });

    it('exports cloud device-flow helpers from the clients entrypoint', () => {
      expect(isOpenHandsCloudHost('https://app.all-hands.dev')).toBe(true);
      expect(isOpenHandsCloudHost('https://all-hands.dev.evil.example')).toBe(false);
      expect(new DeviceFlowError('denied', 'access_denied').code).toBe('access_denied');
    });
  });

  describe('AgentProfilesClient', () => {
    it('listAgentProfiles fetches /api/agent-profiles', async () => {
      const payload = {
        profiles: [
          {
            id: 'uuid-1',
            name: 'default',
            agent_kind: 'openhands',
            revision: 0,
            llm_profile_ref: 'gpt-4o',
            mcp_server_refs: null,
          },
        ],
        active_agent_profile_id: 'uuid-1',
      };
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify(payload), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com', apiKey: 'k' });
      const result = await client.listAgentProfiles();

      expect(result.active_agent_profile_id).toBe('uuid-1');
      expect(result.profiles).toHaveLength(1);
      expect(result.profiles[0].name).toBe('default');
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/agent-profiles',
        expect.objectContaining({ method: 'GET' })
      );
    });

    it('getAgentProfile sets X-Expose-Secrets header when requested', async () => {
      const payload = { name: 'default', profile: { agent_kind: 'openhands' } };
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify(payload), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      await client.getAgentProfile('default', { exposeSecrets: 'plaintext' });

      const call = (global.fetch as Mock).mock.calls[0];
      expect(call[0]).toBe('http://example.com/api/agent-profiles/default');
      const headers = call[1]?.headers as Record<string, string>;
      expect(headers['X-Expose-Secrets']).toBe('plaintext');
    });

    it('saveAgentProfile posts to /api/agent-profiles/{name}', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({ name: 'myprofile', message: "Agent profile 'myprofile' saved" }),
          {
            status: 201,
            headers: { 'content-type': 'application/json' },
          }
        )
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      const result = await client.saveAgentProfile('myprofile', {
        agent_kind: 'openhands',
        llm_profile_ref: 'gpt-4o',
      });

      expect(result.name).toBe('myprofile');
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/agent-profiles/myprofile',
        expect.objectContaining({ method: 'POST' })
      );
      const body = JSON.parse((global.fetch as Mock).mock.calls[0][1].body as string);
      expect(body).toEqual({ agent_kind: 'openhands', llm_profile_ref: 'gpt-4o' });
    });

    it('deleteAgentProfile sends DELETE to /api/agent-profiles/{name}', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({ name: 'myprofile', message: "Agent profile 'myprofile' deleted" }),
          {
            status: 200,
            headers: { 'content-type': 'application/json' },
          }
        )
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      const result = await client.deleteAgentProfile('myprofile');

      expect(result.name).toBe('myprofile');
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/agent-profiles/myprofile',
        expect.objectContaining({ method: 'DELETE' })
      );
    });

    it('renameAgentProfile posts new_name', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ name: 'newname', message: 'renamed' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      await client.renameAgentProfile('oldname', 'newname');

      const body = JSON.parse((global.fetch as Mock).mock.calls[0][1].body as string);
      expect(body.new_name).toBe('newname');
    });

    it('activateAgentProfile posts to /{profileId}/activate', async () => {
      const profileId = 'uuid-abc-123';
      global.fetch = vi
        .fn()
        .mockResolvedValue(
          new Response(
            JSON.stringify({ id: profileId, message: 'activated', agent_settings_applied: false }),
            { status: 200, headers: { 'content-type': 'application/json' } }
          )
        ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      const result = await client.activateAgentProfile(profileId);

      expect(result.id).toBe(profileId);
      expect(result.agent_settings_applied).toBe(false);
      expect(global.fetch).toHaveBeenCalledWith(
        `http://example.com/api/agent-profiles/${profileId}/activate`,
        expect.objectContaining({ method: 'POST' })
      );
    });

    it('materializeAgentProfile posts to /{name}/materialize', async () => {
      const diagnostics = {
        agent_kind: 'openhands',
        valid: true,
        errors: [],
        llm_profile_ref: 'gpt-4o',
        llm_profile_resolved: true,
        llm_api_key_set: true,
        mcp_server_refs: null,
        resolved_mcp_config_keys: [],
        dangling_mcp_server_refs: [],
        acp_api_key_secret_name: null,
        acp_base_url_secret_name: null,
        acp_file_secret_names: [],
        resolved_settings: {},
      };
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify(diagnostics), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      const result = await client.materializeAgentProfile('default');

      expect(result.valid).toBe(true);
      expect(result.llm_profile_ref).toBe('gpt-4o');
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/agent-profiles/default/materialize',
        expect.objectContaining({ method: 'POST' })
      );
    });

    it('materializeAgentProfile sends a draft as the profile body', async () => {
      global.fetch = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ agent_kind: 'openhands', valid: true, errors: [] }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

      const client = new AgentProfilesClient({ host: 'http://example.com' });
      const draft = {
        agent_kind: 'openhands' as const,
        llm_profile_ref: 'gpt-4o',
        tools: [{ name: 'terminal', params: {} }],
      };
      await client.materializeAgentProfile('draft', draft);

      const [, init] = (global.fetch as Mock).mock.calls[0];
      expect(JSON.parse(init.body)).toEqual({ profile: draft });
    });
  });

  it('ToolClient.getToolCatalog gets /api/tools/catalog', async () => {
    const catalog = {
      tools: [
        {
          name: 'terminal',
          user_selectable: true,
          usable: true,
          description: 'Run shell commands',
          in_default_set: true,
        },
      ],
    };
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify(catalog), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ToolClient({ host: 'http://example.com' });

    expect(await client.getToolCatalog()).toEqual(catalog);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/tools/catalog',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('Workspace exposes bash namespace', () => {
    const workspace = new Workspace({
      host: 'http://example.com',
      workingDir: '/tmp',
      apiKey: 'secret',
    });

    expect(workspace.bash).toBeInstanceOf(BashClient);
    expect(workspace.bash.host).toBe('http://example.com');
    expect(workspace.bash.apiKey).toBe('secret');
  });

  it('ServerClient.getReady accepts a 503 readiness response', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ status: 'initializing', message: 'Booting' }), {
        status: 503,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ServerClient({ host: 'http://example.com' });
    const ready = await client.getReady();

    expect(ready.status).toBe('initializing');
    expect(ready.message).toBe('Booting');
  });

  it('RemoteEventsList can be constructed from client options', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ items: [], next_page_id: null }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const events = new RemoteEventsList({ baseUrl: 'http://example.com', apiKey: 'secret' }, 'c1');
    const page = await events.search({ limit: 25 });

    expect(page.items).toEqual([]);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/c1/events/search?limit=25',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({
          'X-Session-API-Key': 'secret',
        }),
      })
    );
  });

  it('ConversationClient.switchLLM posts an explicit LLM config', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await client.switchLLM('c1', { model: 'gpt-4o', api_key: 'encrypted' });

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/c1/switch_llm',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ llm: { model: 'gpt-4o', api_key: 'encrypted' } }),
      })
    );
  });

  it('ACPClient.discoverModels posts the agent and secrets and returns the discovery', async () => {
    const discovery = {
      agent_name: 'pi-acp',
      agent_version: '0.0.33',
      current_model_id: 'anthropic/claude-opus-4-8',
      available_models: [{ model_id: 'anthropic/claude-opus-4-8', name: 'Opus 4.8' }],
      supports_runtime_model_switch: true,
      error: null,
    };
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify(discovery), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;
    const request = {
      agent_settings: { agent_kind: 'acp' as const, acp_server: 'pi' },
      secrets: {
        ANTHROPIC_API_KEY: {
          kind: 'LookupSecret' as const,
          url: '/api/settings/secrets/ANTHROPIC_API_KEY',
        },
      },
    };

    const client = new ACPClient({ host: 'http://example.com/', apiKey: 'secret' });
    const result = await client.discoverModels(request);

    expect(result).toEqual(discovery);
    const [url, init] = (global.fetch as Mock).mock.calls[0];
    expect(url).toBe('http://example.com/api/acp/models');
    expect(init).toMatchObject({ method: 'POST' });
    expect(JSON.parse(init.body as string)).toEqual(request);
  });

  it('LLMMetadataClient.getOpenAISubscriptionModels returns models array', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ vendor: 'openai', models: ['gpt-5.2', 'gpt-5.3-codex'] }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new LLMMetadataClient({ host: 'http://example.com', apiKey: 'secret' });
    const models = await client.getOpenAISubscriptionModels();

    expect(models).toEqual(['gpt-5.2', 'gpt-5.3-codex']);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/llm/subscription/openai/models',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('LLMMetadataClient calls OpenAI subscription endpoints without exposing tokens', async () => {
    const responses = [
      { vendor: 'openai', connected: false, account_email: null, expires_at: null },
      {
        device_code: 'opaque-token',
        user_code: 'ABCD-EFGH',
        verification_uri: 'https://auth.example/device',
        verification_uri_complete: null,
        expires_at: 4102444800000,
        interval_seconds: 5,
      },
      { vendor: 'openai', connected: true, account_email: null, expires_at: 4102444800000 },
      { vendor: 'openai', connected: false, account_email: null, expires_at: null },
    ];
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify(responses.shift()), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const client = new LLMMetadataClient({ host: 'http://example.com', apiKey: 'secret' });

    await expect(client.getOpenAISubscriptionStatus()).resolves.toMatchObject({
      vendor: 'openai',
      connected: false,
    });
    await expect(client.startOpenAISubscriptionDeviceLogin()).resolves.toMatchObject({
      device_code: 'opaque-token',
      user_code: 'ABCD-EFGH',
    });
    await expect(client.pollOpenAISubscriptionDeviceLogin('opaque-token')).resolves.toMatchObject({
      connected: true,
      expires_at: 4102444800000,
    });
    await expect(client.logoutOpenAISubscription()).resolves.toMatchObject({ connected: false });

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/llm/subscription/openai/status',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/llm/subscription/openai/device/start',
      expect.objectContaining({ method: 'POST' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/llm/subscription/openai/device/poll',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ device_code: 'opaque-token' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/llm/subscription/openai/logout',
      expect.objectContaining({ method: 'POST' })
    );
    expect(JSON.stringify((global.fetch as Mock).mock.calls)).not.toContain('access-token');
    expect(JSON.stringify((global.fetch as Mock).mock.calls)).not.toContain('refresh-token');
  });

  it('SkillsClient.syncSkills posts to the sync endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ status: 'success', message: 'ok' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new SkillsClient({ host: 'http://example.com' });
    const response = await client.syncSkills();

    expect(response.status).toBe('success');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/skills/sync',
      expect.objectContaining({
        method: 'POST',
        body: '{}',
      })
    );
  });

  it('SkillsClient CRUD methods map to the correct endpoints', async () => {
    const installedSkill = {
      name: 'my-skill',
      version: '1.0.0',
      description: 'A test skill',
      enabled: true,
      source: '/tmp/my-skill',
      installed_at: '2026-05-12T12:00:00Z',
      install_path: '/home/.openhands/skills/installed/my-skill',
    };
    const installedList = { skills: [{ name: 'my-skill', version: '1.0.0', enabled: true }] };
    const toggleResponse = { name: 'my-skill', enabled: false };
    const uninstallResponse = { message: "Skill 'my-skill' uninstalled" };
    const refreshResponse = {
      message: "Skill 'my-skill' updated",
      skill: { name: 'my-skill', version: '1.0.0', enabled: true },
    };
    const marketplaceResponse = {
      skills: [
        { name: 'my-skill', description: 'desc', source: 'github:org/repo', installed: false },
      ],
    };

    const responses = [
      installedSkill,
      installedList,
      installedSkill,
      toggleResponse,
      uninstallResponse,
      refreshResponse,
      marketplaceResponse,
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new SkillsClient({ host: 'http://example.com' });

    const installed = await client.installSkill({ source: '/tmp/my-skill', force: false });
    expect(installed.name).toBe('my-skill');
    expect(installed.enabled).toBe(true);

    const list = await client.listInstalledSkills();
    expect(list.skills).toHaveLength(1);
    expect(list.skills[0].name).toBe('my-skill');

    const got = await client.getInstalledSkill('my-skill');
    expect(got.name).toBe('my-skill');

    const toggled = await client.toggleSkill('my-skill', false);
    expect(toggled.enabled).toBe(false);

    const uninstalled = await client.uninstallSkill('my-skill');
    expect(uninstalled.message).toContain('uninstalled');

    const refreshed = await client.refreshSkill('my-skill');
    expect(refreshed.message).toContain('updated');
    expect(refreshed.skill.name).toBe('my-skill');

    const marketplace = await client.getMarketplace();
    expect(marketplace.skills).toHaveLength(1);
    expect(marketplace.skills[0].installed).toBe(false);

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/skills/install',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ source: '/tmp/my-skill', force: false }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/skills/installed',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/skills/installed/my-skill',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/skills/installed/my-skill',
      expect.objectContaining({ method: 'PATCH', body: JSON.stringify({ enabled: false }) })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/skills/installed/my-skill',
      expect.objectContaining({ method: 'DELETE' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      6,
      'http://example.com/api/skills/installed/my-skill/refresh',
      expect.objectContaining({ method: 'POST' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      7,
      'http://example.com/api/skills/marketplace',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('SkillsClient.refreshSkill POSTs to the /refresh route', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ message: 'updated', skill: { name: 'my-skill' } }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new SkillsClient({ host: 'http://example.com' });
    const refreshed = await client.refreshSkill('my-skill');

    expect(refreshed.message).toBe('updated');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/skills/installed/my-skill/refresh',
      expect.objectContaining({ method: 'POST' })
    );
  });

  it('SkillsClient percent-encodes skill names with special characters', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'my skill', enabled: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new SkillsClient({ host: 'http://example.com' });
    await client.getInstalledSkill('my skill');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/skills/installed/my%20skill',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('SubAgentsClient.getSubAgents POSTs the request to /api/sub-agents', async () => {
    const payload = {
      agents: [
        {
          name: 'general-purpose',
          description: 'A general-purpose delegate agent',
          model: 'inherit',
          color: null,
          tools: ['bash', 'str_replace_editor'],
          skills: [],
          system_prompt: 'You are a helpful sub-agent.',
          when_to_use_examples: ['Use for broad research tasks'],
          permission_mode: null,
          max_iteration_per_run: null,
          max_budget_per_run: null,
          mcp_servers: null,
          profile_store_dir: null,
          hooks: null,
          condenser: null,
          metadata: {},
          level: 'builtin',
          source: null,
          is_builtin: true,
        },
        {
          name: 'code-explorer',
          description: 'Explores a codebase',
          model: 'inherit',
          color: 'blue',
          tools: ['bash'],
          skills: ['grep'],
          system_prompt: 'Explore the repository.',
          when_to_use_examples: [],
          permission_mode: 'confirm_risky',
          max_iteration_per_run: 25,
          max_budget_per_run: 1.5,
          mcp_servers: { fetch: { command: 'uvx', args: ['mcp-server-fetch'] } },
          profile_store_dir: null,
          hooks: null,
          condenser: null,
          metadata: { team: 'core' },
          level: 'project',
          source: '/workspace/.openhands/agents/code-explorer.md',
          is_builtin: false,
        },
      ],
    };
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify(payload), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new SubAgentsClient({ host: 'http://example.com', apiKey: 'secret' });
    const request = {
      load_user: true,
      load_project: true,
      load_builtin: false,
      project_dir: '/workspace',
    };
    const response = await client.getSubAgents(request);

    expect(response.agents).toHaveLength(2);
    expect(response.agents[0].name).toBe('general-purpose');
    expect(response.agents[0].is_builtin).toBe(true);
    expect(response.agents[0].level).toBe('builtin');
    expect(response.agents[1].name).toBe('code-explorer');
    expect(response.agents[1].level).toBe('project');
    expect(response.agents[1].mcp_servers).toEqual({
      fetch: { command: 'uvx', args: ['mcp-server-fetch'] },
    });

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/sub-agents',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify(request),
        headers: expect.objectContaining({ 'X-Session-API-Key': 'secret' }),
      })
    );
  });

  it('SubAgentsClient.getSubAgents defaults to an empty request body', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ agents: [] }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new SubAgentsClient({ host: 'http://example.com' });
    const response = await client.getSubAgents();

    expect(response.agents).toEqual([]);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/sub-agents',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({}),
      })
    );
  });

  it('PluginsClient.getPluginsMarketplace fetches the plugins marketplace', async () => {
    const payload = {
      plugins: [
        {
          name: 'city-weather',
          description: 'Weather plugin',
          source: 'github:OpenHands/extensions',
          ref: null,
          repo_path: 'plugins/city-weather',
          installed: false,
        },
      ],
    };
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify(payload), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new PluginsClient({ host: 'http://example.com' });
    const result = await client.getPluginsMarketplace();

    expect(result.plugins).toHaveLength(1);
    expect(result.plugins[0].installed).toBe(false);
    expect(result.plugins[0].repo_path).toBe('plugins/city-weather');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/plugins/marketplace',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('PluginsClient management methods map to the correct endpoints', async () => {
    const installedPlugin = {
      name: 'demo-plugin',
      version: '1.0.0',
      description: 'A test plugin',
      enabled: true,
      source: '/tmp/demo-plugin',
      resolved_ref: null,
      repo_path: null,
      installed_at: '2026-05-12T12:00:00Z',
      install_path: '/home/.openhands/plugins/installed/demo-plugin',
    };
    const availableList = {
      plugins: [{ name: 'demo-plugin', version: '1.0.0', description: 'A test plugin' }],
    };
    const installedList = { plugins: [installedPlugin] };
    const toggleResponse = { name: 'demo-plugin', enabled: false };
    const uninstallResponse = { message: "Plugin 'demo-plugin' uninstalled" };
    const refreshResponse = {
      message: "Plugin 'demo-plugin' updated",
      plugin: installedPlugin,
    };

    const responses = [
      availableList,
      installedPlugin,
      installedList,
      installedPlugin,
      toggleResponse,
      uninstallResponse,
      refreshResponse,
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new PluginsClient({ host: 'http://example.com' });

    const available = await client.getPlugins({ load_user: true, load_project: false });
    expect(available.plugins[0].name).toBe('demo-plugin');

    const installed = await client.installPlugin({
      source: '/tmp/demo-plugin',
      force: false,
    });
    expect(installed.name).toBe('demo-plugin');
    expect(installed.enabled).toBe(true);

    const list = await client.listInstalledPlugins();
    expect(list.plugins).toHaveLength(1);

    const got = await client.getInstalledPlugin('demo-plugin');
    expect(got.name).toBe('demo-plugin');

    const toggled = await client.setPluginEnabled('demo-plugin', false);
    expect(toggled.enabled).toBe(false);

    const uninstalled = await client.uninstallPlugin('demo-plugin');
    expect(uninstalled.message).toContain('uninstalled');

    const refreshed = await client.refreshPlugin('demo-plugin');
    expect(refreshed.message).toContain('updated');
    expect(refreshed.plugin.name).toBe('demo-plugin');

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/plugins',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ load_user: true, load_project: false }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/plugins/install',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ source: '/tmp/demo-plugin', force: false }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/plugins/installed',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/plugins/installed/demo-plugin',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/plugins/installed/demo-plugin',
      expect.objectContaining({
        method: 'PATCH',
        body: JSON.stringify({ enabled: false }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      6,
      'http://example.com/api/plugins/installed/demo-plugin',
      expect.objectContaining({ method: 'DELETE' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      7,
      'http://example.com/api/plugins/installed/demo-plugin/refresh',
      expect.objectContaining({ method: 'POST' })
    );
  });

  it('WorkspacesClient checks agent-server version before listing workspaces', async () => {
    const responses = [
      { version: '1.23.0', uptime: 1, idle_time: 0 },
      {
        workspaces: [
          {
            id: '/repo',
            name: 'repo',
            path: '/repo',
            parentPath: '/home',
          },
        ],
        workspaceParents: [{ id: '/home', name: 'home', path: '/home' }],
      },
      {
        workspaces: [
          {
            id: '/repo',
            name: 'repo',
            path: '/repo',
            parentPath: '/home',
          },
          {
            id: '/repo2',
            name: 'repo2',
            path: '/repo2',
            parentPath: '/home',
          },
        ],
        workspaceParents: [{ id: '/home', name: 'home', path: '/home' }],
      },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new WorkspacesClient({ host: 'http://example.com' });
    const listed = await client.listWorkspaces();
    const updated = await client.addWorkspaces([
      { id: '/repo2', name: 'repo2', path: '/repo2', parentPath: '/home' },
    ]);

    expect(listed.workspaces).toHaveLength(1);
    expect(updated.workspaces).toHaveLength(2);
    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/server_info',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/workspaces',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/workspaces',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({
          workspaces: [{ id: '/repo2', name: 'repo2', path: '/repo2', parentPath: '/home' }],
        }),
      })
    );
  });

  it('WorkspacesClient retries agent-server info after a transient failure', async () => {
    global.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ detail: 'temporarily unavailable' }), {
          status: 503,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ version: '1.23.0', uptime: 1, idle_time: 0 }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ workspaces: [], workspaceParents: [] }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      ) as typeof fetch;

    const client = new WorkspacesClient({ host: 'http://example.com' });

    await expect(client.listWorkspaces()).rejects.toMatchObject({ status: 503 });
    await expect(client.listWorkspaces()).resolves.toEqual({
      workspaces: [],
      workspaceParents: [],
    });

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/server_info',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/server_info',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/workspaces',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('WorkspacesClient throws AgentServerVersionError for old agent servers', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ version: '1.22.1', uptime: 1, idle_time: 0 }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new WorkspacesClient({ host: 'http://example.com' });

    await expect(client.listWorkspaces()).rejects.toMatchObject({
      code: 'AGENT_SERVER_VERSION_TOO_OLD',
      feature: 'workspaces',
      requiredVersion: '1.23.0',
      actualVersion: '1.22.1',
    });

    try {
      await client.listWorkspaces();
    } catch (error) {
      expect(error).toBeInstanceOf(AgentServerVersionError);
      expect(isAgentServerVersionError(error)).toBe(true);
    }

    expect(global.fetch).toHaveBeenCalledTimes(1);
  });

  it('compares agent-server semantic versions', () => {
    expect(compareAgentServerVersions('1.23.0', '1.23.0')).toBe(0);
    expect(compareAgentServerVersions('v1.24.0+build.1', '1.23.0')).toBe(1);
    expect(compareAgentServerVersions('1.22.9', '1.23.0')).toBe(-1);
    expect(compareAgentServerVersions('1.23.0-rc.1', '1.23.0')).toBe(-1);
    expect(compareAgentServerVersions('not-a-version', '1.23.0')).toBeNull();
  });

  it('BashClient.startCommand normalizes string requests', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          id: 'bash-command-1',
          timestamp: new Date().toISOString(),
          command: 'echo hi',
          cwd: '/tmp',
          timeout: 3,
          kind: 'BashCommand',
        }),
        {
          status: 200,
          headers: { 'content-type': 'application/json' },
        }
      )
    ) as typeof fetch;

    const client = new BashClient({ host: 'http://example.com' });
    const result = await client.startCommand('echo hi', '/tmp', 3.8);

    expect(result.command).toBe('echo hi');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/bash/start_bash_command',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ command: 'echo hi', cwd: '/tmp', timeout: 3 }),
      })
    );
  });

  it('BashClient.stopCommand POSTs to the stop endpoint and swallows 404', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new BashClient({ host: 'http://example.com' });
    await client.stopCommand('cmd-1');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/bash/bash_commands/cmd-1/stop',
      expect.objectContaining({ method: 'POST' })
    );

    global.fetch = vi
      .fn()
      .mockResolvedValue(new Response('Not Found', { status: 404 })) as typeof fetch;

    await expect(client.stopCommand('missing')).resolves.toBeUndefined();
  });

  it('ProfilesClient.listProfiles GETs the profiles endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          profiles: [{ name: 'default', model: 'gpt-4o', api_key_set: true }],
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.listProfiles();

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles[0].name).toBe('default');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('ProfilesClient.getProfile sends X-Expose-Secrets header when requested', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          name: 'default',
          config: { model: 'gpt-4o', api_key: 'sk-x' },
          api_key_set: true,
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.getProfile('default', { exposeSecrets: 'plaintext' });

    expect(result.name).toBe('default');
    expect(result.api_key_set).toBe(true);
    const fetchMock = global.fetch as Mock;
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe('http://example.com/api/profiles/default');
    expect(init.method).toBe('GET');
    expect(init.headers['X-Expose-Secrets']).toBe('plaintext');
  });

  it('ProfilesClient.getProfile omits X-Expose-Secrets header by default', async () => {
    global.fetch = vi
      .fn()
      .mockResolvedValue(
        new Response(
          JSON.stringify({ name: 'default', config: { model: 'gpt-4o' }, api_key_set: false }),
          { status: 200, headers: { 'content-type': 'application/json' } }
        )
      ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    await client.getProfile('default');

    const fetchMock = global.fetch as Mock;
    const [, init] = fetchMock.mock.calls[0];
    expect(init.headers['X-Expose-Secrets']).toBeUndefined();
  });

  it('ProfilesClient.getProfile percent-encodes the profile name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'my profile', config: {}, api_key_set: false }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    await client.getProfile('my profile');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/my%20profile',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('ProfilesClient.saveProfile POSTs the profile body', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'default', message: "Profile 'default' saved" }), {
        status: 201,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.saveProfile('default', {
      llm: { model: 'gpt-4o', api_key: 'sk-secret' },
      include_secrets: true,
    });

    expect(result.name).toBe('default');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/default',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({
          llm: { model: 'gpt-4o', api_key: 'sk-secret' },
          include_secrets: true,
        }),
      })
    );
  });

  it('ProfilesClient.deleteProfile DELETEs the profile endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'default', message: "Profile 'default' deleted" }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.deleteProfile('default');

    expect(result.name).toBe('default');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/default',
      expect.objectContaining({ method: 'DELETE' })
    );
  });

  it('ProfilesClient.renameProfile POSTs to the rename endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'new', message: "Profile 'old' renamed to 'new'" }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.renameProfile('old', 'new');

    expect(result.name).toBe('new');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/old/rename',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ new_name: 'new' }),
      })
    );
  });

  it('ProfilesClient.getProfile sends X-Expose-Secrets: encrypted', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          name: 'default',
          config: { model: 'gpt-4o', api_key: 'gAAAAA-encrypted-blob' },
          api_key_set: true,
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.getProfile('default', { exposeSecrets: 'encrypted' });

    expect(result.config.api_key).toBe('gAAAAA-encrypted-blob');
    const fetchMock = global.fetch as Mock;
    const [, init] = fetchMock.mock.calls[0];
    expect(init.headers['X-Expose-Secrets']).toBe('encrypted');
  });

  it('ProfilesClient.getProfile surfaces HttpError on 404', async () => {
    global.fetch = vi.fn(
      async () =>
        new Response(JSON.stringify({ detail: "Profile 'missing' not found" }), {
          status: 404,
          statusText: 'Not Found',
          headers: { 'content-type': 'application/json' },
        })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const error = await client.getProfile('missing').catch((e: unknown) => e);
    expect(error).toBeInstanceOf(HttpError);
    expect((error as HttpError).status).toBe(404);
    expect((error as HttpError).response).toEqual({ detail: "Profile 'missing' not found" });
  });

  it('ProfilesClient.saveProfile omits include_secrets when not provided', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'default', message: "Profile 'default' saved" }), {
        status: 201,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    await client.saveProfile('default', { llm: { model: 'gpt-4o' } });

    const fetchMock = global.fetch as Mock;
    const [, init] = fetchMock.mock.calls[0];
    const body = JSON.parse(init.body as string);
    expect(body).toEqual({ llm: { model: 'gpt-4o' } });
    expect(body).not.toHaveProperty('include_secrets');
  });

  it('ProfilesClient.validateProfile POSTs to the validate endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ valid: true, error: null }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const request = { llm: { model: 'gpt-4o', api_key: 'sk-secret' }, include_secrets: true };
    const result = await client.validateProfile('default', request);

    expect(result.valid).toBe(true);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/default/validate',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify(request),
      })
    );
  });

  it('ProfilesClient.validateProfile returns a valid=false verdict with the error', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          valid: false,
          error: {
            type: 'LLMAuthenticationError',
            message: 'Invalid or expired API key',
          },
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.validateProfile('default', { llm: { model: 'gpt-4o' } });

    expect(result.valid).toBe(false);
    expect(result.error?.type).toBe('LLMAuthenticationError');
    expect(result.error?.message).toContain('Invalid or expired');
  });

  it('ProfilesClient.validateProfile percent-encodes the profile name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ valid: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    await client.validateProfile('my profile', { llm: { model: 'gpt-4o' } });

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/my%20profile/validate',
      expect.objectContaining({ method: 'POST' })
    );
  });

  it('ProfilesClient.validateProfile surfaces HttpError on 404', async () => {
    global.fetch = vi.fn(
      async () =>
        new Response(JSON.stringify({ detail: 'Not Found' }), {
          status: 404,
          statusText: 'Not Found',
          headers: { 'content-type': 'application/json' },
        })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const error = await client
      .validateProfile('default', { llm: { model: 'gpt-4o' } })
      .catch((e: unknown) => e);
    expect(error).toBeInstanceOf(HttpError);
    expect((error as HttpError).status).toBe(404);
  });

  it('ProfilesClient.renameProfile percent-encodes the source name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'fresh', message: 'renamed' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    await client.renameProfile('my profile', 'fresh');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/my%20profile/rename',
      expect.objectContaining({ method: 'POST' })
    );
  });

  it('ProfilesClient.activateProfile POSTs to the activate endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          name: 'default',
          message: "Profile 'default' activated and applied to current settings",
          llm_applied: true,
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new ProfilesClient({ host: 'http://example.com' });
    const result = await client.activateProfile('my profile');

    expect(result.name).toBe('default');
    expect(result.llm_applied).toBe(true);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/profiles/my%20profile/activate',
      expect.objectContaining({
        method: 'POST',
        body: '{}',
      })
    );
  });

  it('MetaProfilesClient.listMetaProfiles GETs the meta-profiles endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          meta_profiles: [
            {
              name: 'balanced',
              classifier_model: 'classifier',
              num_classes: 2,
            },
          ],
          active_meta_profile: 'balanced',
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new MetaProfilesClient({ host: 'http://example.com' });
    const result = await client.listMetaProfiles();

    expect(result.meta_profiles).toHaveLength(1);
    expect(result.meta_profiles[0].name).toBe('balanced');
    expect(result.active_meta_profile).toBe('balanced');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/meta-profiles',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('MetaProfilesClient.getMetaProfile percent-encodes the name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          name: 'my profile',
          config: {
            classifier_model: 'classifier',
            classes: [{ description: 'UI', model: 'fast' }],
          },
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new MetaProfilesClient({ host: 'http://example.com' });
    const result = await client.getMetaProfile('my profile');

    expect(result.name).toBe('my profile');
    expect(result.config.classes).toHaveLength(1);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/meta-profiles/my%20profile',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('MetaProfilesClient.saveMetaProfile POSTs the meta-profile body', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ name: 'balanced', message: "Meta-profile 'balanced' saved" }), {
        status: 201,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new MetaProfilesClient({ host: 'http://example.com' });
    const config = {
      classifier_model: 'classifier',
      classes: [{ description: 'tests', model: 'slow' }],
    };
    const result = await client.saveMetaProfile('balanced', config);

    expect(result.name).toBe('balanced');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/meta-profiles/balanced',
      expect.objectContaining({ method: 'POST', body: JSON.stringify(config) })
    );
  });

  it('MetaProfilesClient.deleteMetaProfile DELETEs the meta-profile endpoint', async () => {
    global.fetch = vi
      .fn()
      .mockResolvedValue(
        new Response(
          JSON.stringify({ name: 'balanced', message: "Meta-profile 'balanced' deleted" }),
          { status: 200, headers: { 'content-type': 'application/json' } }
        )
      ) as typeof fetch;

    const client = new MetaProfilesClient({ host: 'http://example.com' });
    const result = await client.deleteMetaProfile('balanced');

    expect(result.name).toBe('balanced');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/meta-profiles/balanced',
      expect.objectContaining({ method: 'DELETE' })
    );
  });

  it('MetaProfilesClient.activateMetaProfile POSTs to the activate endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          name: 'balanced',
          message: "Meta-profile 'balanced' activated",
          applied: true,
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new MetaProfilesClient({ host: 'http://example.com' });
    const result = await client.activateMetaProfile('balanced');

    expect(result.name).toBe('balanced');
    expect(result.applied).toBe(true);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/meta-profiles/balanced/activate',
      expect.objectContaining({ method: 'POST', body: '{}' })
    );
  });

  it('RemoteConversation.switchLlm POSTs the llm to the switch_llm endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    const llm = { model: 'gpt-4o-mini', api_key: 'sk-new' };
    await conversation.switchLlm(llm);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/switch_llm',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ llm }),
      })
    );
  });

  it('RemoteConversation.switchAcpEffort POSTs the effort', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;
    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    await conversation.switchAcpEffort('low');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/switch_acp_effort',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ effort: 'low' }) })
    );
  });

  it('RemoteConversation.switchAcpModel POSTs the model to the switch_acp_model endpoint', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    await conversation.switchAcpModel('claude-haiku-4-5');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/switch_acp_model',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ model: 'claude-haiku-4-5' }),
      })
    );
  });

  it('RemoteConversation.startGoal includes max_iterations only when provided and surfaces HttpError 409', async () => {
    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    // Omitted maxIterations must not appear on the wire (server default applies).
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;
    await conversation.startGoal('Fix the failing test');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/goal',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ objective: 'Fix the failing test' }),
      })
    );

    // A 409 from the server (run/goal already active) must propagate as HttpError,
    // and maxIterations must be forwarded when supplied.
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ detail: 'Conversation run or goal loop already running.' }), {
        status: 409,
        statusText: 'Conflict',
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;
    const error = await conversation.startGoal('Fix the failing test', 5).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(HttpError);
    expect((error as HttpError).status).toBe(409);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/goal',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ objective: 'Fix the failing test', max_iterations: 5 }),
      })
    );
  });

  it('RemoteConversation.resumeGoal POSTs to goal/resume and surfaces HttpError 400 when nothing is resumable', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ detail: 'no_resumable_goal' }), {
        status: 400,
        statusText: 'Bad Request',
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    const error = await conversation.resumeGoal().catch((e: unknown) => e);
    expect(error).toBeInstanceOf(HttpError);
    expect((error as HttpError).status).toBe(400);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/goal/resume',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
    );
  });

  it('RemoteConversation.stopGoal POSTs to goal/stop and surfaces HttpError 404 for a missing conversation', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ detail: 'Item not found' }), {
        status: 404,
        statusText: 'Not Found',
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    const error = await conversation.stopGoal().catch((e: unknown) => e);
    expect(error).toBeInstanceOf(HttpError);
    expect((error as HttpError).status).toBe(404);
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/goal/stop',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
    );
  });

  it('RemoteConversation.setConfirmationPolicy wraps the SDK v1.23.0 request body', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    await conversation.setConfirmationPolicy({ kind: 'NeverConfirm' });

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/confirmation_policy',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ policy: { kind: 'NeverConfirm' } }),
      })
    );
  });

  it('RemoteConversation.start sends the optional observability user ID', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: 'conv-123' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      userId: 'user-42',
    });

    await conversation.start({ initialMessage: 'hello' });

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations',
      expect.objectContaining({
        method: 'POST',
      })
    );
    const [, init] = (global.fetch as Mock).mock.calls[0];
    expect(JSON.parse(init.body)).toMatchObject({
      user_id: 'user-42',
      initial_message: {
        role: 'user',
        content: [{ type: 'text', text: 'hello' }],
      },
    });
  });

  it('ConversationManager.createACPConversation sends the optional observability user ID', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: 'acp-123' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const manager = new ConversationManager({ host: 'http://example.com' });
    await manager.createACPConversation(
      { kind: 'ACPAgent', llm: { model: 'gpt-4o' } },
      { userId: 'user-42' }
    );

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations',
      expect.objectContaining({
        method: 'POST',
      })
    );
    const [, init] = (global.fetch as Mock).mock.calls[0];
    expect(JSON.parse(init.body)).toMatchObject({
      user_id: 'user-42',
    });
  });

  it('HttpClient can parse blob responses when requested', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(new Blob(['zip-data']), {
        status: 200,
        headers: { 'content-type': 'application/zip' },
      })
    ) as typeof fetch;

    const client = new HttpClient({ baseUrl: 'http://example.com' });
    const response = await client.get<Blob>('/download.zip', { responseType: 'blob' });

    expect(response.data).toBeInstanceOf(Blob);
    expect(await response.data.text()).toBe('zip-data');
  });

  it.each([undefined, 'reload'] as const)(
    'HttpClient forwards cache=%s without changing the default',
    async (cache) => {
      global.fetch = vi.fn().mockResolvedValue(new Response('file contents')) as typeof fetch;
      const client = new HttpClient({ baseUrl: 'http://example.com' });

      const response = await client.get('/download.txt', { cache });

      expect(response.data).toBe('file contents');
      expect((global.fetch as Mock).mock.calls[0][1].cache).toBe(cache);
    }
  );
  it('SettingsClient manages LLM profiles', async () => {
    const responses = [
      { profiles: [{ name: 'fast', model: 'openai/gpt-4o', base_url: null, api_key_set: true }] },
      { name: 'fast', config: { model: 'openai/gpt-4o', api_key: 'encrypted' }, api_key_set: true },
      { name: 'fast', message: "Profile 'fast' saved" },
      { name: 'slow', message: "Profile 'fast' renamed to 'slow'" },
      { name: 'slow', message: "Profile 'slow' deleted" },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new SettingsClient({ host: 'http://example.com' });

    await expect(client.listProfiles()).resolves.toEqual({
      profiles: [{ name: 'fast', model: 'openai/gpt-4o', base_url: null, api_key_set: true }],
    });
    await expect(client.getProfile('fast', { exposeSecrets: 'encrypted' })).resolves.toEqual({
      name: 'fast',
      config: { model: 'openai/gpt-4o', api_key: 'encrypted' },
      api_key_set: true,
    });
    await client.saveProfile('fast', { llm: { model: 'openai/gpt-4o' } });
    await client.renameProfile('fast', 'slow');
    await client.deleteProfile('slow');

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/profiles',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/profiles/fast',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ 'X-Expose-Secrets': 'encrypted' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/profiles/fast',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ llm: { model: 'openai/gpt-4o' } }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/profiles/fast/rename',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ new_name: 'slow' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/profiles/slow',
      expect.objectContaining({ method: 'DELETE' })
    );
  });

  it('ConversationClient.switchProfile posts the profile name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await client.switchProfile('conversation-1', 'fast');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/switch_profile',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ profile_name: 'fast' }),
      })
    );
  });

  it('ConversationClient.switchAcpEffort posts the effort', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    await new ConversationClient({ host: 'http://example.com' }).switchAcpEffort(
      'conversation-1',
      'high'
    );

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/switch_acp_effort',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ effort: 'high' }) })
    );
  });

  it('ConversationClient.switchAcpModel posts the model', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await client.switchAcpModel('conversation-1', 'claude-haiku-4-5');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/switch_acp_model',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ model: 'claude-haiku-4-5' }),
      })
    );
  });

  it('ConversationClient.navigateConversation POSTs event_id and returns the re-rooted info', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: 'conversation-1', leaf_event_id: 'event-7' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    const info = await client.navigateConversation(
      'conversation-1',
      { event_id: 'event-7' },
      { includeSkills: true }
    );

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/navigate?include_skills=true',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ event_id: 'event-7' }),
      })
    );
    // The response carries the new HEAD.
    expect(info.leaf_event_id).toBe('event-7');
  });

  it('ConversationClient.navigateConversation selects the empty tree with a null event_id', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: 'conversation-1', leaf_event_id: null }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await client.navigateConversation('conversation-1', { event_id: null });

    // No includeSkills option => no query string on the URL.
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/navigate',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ event_id: null }),
      })
    );
  });

  it('RemoteConversation.navigateTo POSTs to /navigate then refreshes cached state', async () => {
    // navigateTo posts to the route and then GETs the conversation to refresh
    // the cache (leaf_event_id is not broadcast over the WebSocket). Two calls
    // means each needs its own Response (a body can only be read once).
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify({ id: 'conv-123', leaf_event_id: 'event-3' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    await conversation.navigateTo('event-3');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/navigate',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ event_id: 'event-3' }),
      })
    );
    // The trailing refresh re-reads the conversation from the REST API.
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('RemoteConversation.navigateTo passes a null event_id for the empty tree', async () => {
    // Fresh Response per call: navigateTo posts and then refreshes state.
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify({ id: 'conv-123', leaf_event_id: null }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const agent = new Agent({ llm: { model: 'gpt-4o', api_key: 'k' } });
    const workspace = new RemoteWorkspace({ host: 'http://example.com', workingDir: '/tmp' });
    const conversation = new RemoteConversation(agent, workspace, {
      conversationId: 'conv-123',
    });

    await conversation.navigateTo(null);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conv-123/navigate',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ event_id: null }),
      })
    );
  });

  it('ConversationManager.switchProfile posts the profile name', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    const manager = new ConversationManager({ host: 'http://example.com' });
    await manager.switchProfile('conversation-1', 'fast');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/conversations/conversation-1/switch_profile',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ profile_name: 'fast' }),
      })
    );
  });

  it('updateConversation resolves with the updated ConversationInfo, not the PATCH Success body', async () => {
    const updated = { id: 'c1', title: 'New title', execution_status: 'idle' };
    const jsonResponse = (body: unknown) =>
      new Response(JSON.stringify(body), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      });
    const mockFetch = () =>
      vi
        .fn()
        .mockResolvedValueOnce(jsonResponse({ success: true }))
        .mockResolvedValueOnce(jsonResponse(updated)) as typeof fetch;

    for (const client of [
      new ConversationManager({ host: 'http://example.com' }),
      new ConversationClient({ host: 'http://example.com' }),
    ]) {
      global.fetch = mockFetch();
      const result = await client.updateConversation('c1', { title: 'New title' });

      expect(result).toEqual(updated);
      expect(global.fetch).toHaveBeenNthCalledWith(
        1,
        'http://example.com/api/conversations/c1',
        expect.objectContaining({ method: 'PATCH', body: JSON.stringify({ title: 'New title' }) })
      );
      expect(global.fetch).toHaveBeenNthCalledWith(
        2,
        'http://example.com/api/conversations/c1',
        expect.objectContaining({ method: 'GET' })
      );
    }
  });

  it('SettingsClient lists and switches experimental features', async () => {
    const feature = {
      key: 'qa_feature',
      label: 'QA feature',
      description: 'A feature for tests.',
      enabled: true,
    };
    const responses = [[{ ...feature, enabled: false }], feature];
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify(responses.shift()), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const client = new SettingsClient({ host: 'http://example.com' });
    await expect(client.listExperimentalFeatures()).resolves.toEqual([
      { ...feature, enabled: false },
    ]);
    await expect(client.updateExperimentalFeature('qa_feature', true)).resolves.toEqual(feature);

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/settings/experimental',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/settings/experimental/qa_feature',
      expect.objectContaining({ method: 'PATCH', body: JSON.stringify({ enabled: true }) })
    );
  });

  it('isMessageEditEvent recognizes an edit of an agent message', () => {
    const edit = {
      id: 'e1',
      kind: 'MessageEditEvent',
      source: 'agent',
      timestamp: '2026-11-15T00:00:00Z',
      target_event_id: 'm1',
      text: '~~Should I run it?~~ [Edit: Running it.]',
    };

    expect(isMessageEditEvent(edit)).toBe(true);
    expect(isMessageEditEvent({ ...edit, kind: 'MessageEvent' })).toBe(false);
  });

  it('ConversationClient.react sends only the fields it is given', async () => {
    const saved = {
      id: 'r1',
      kind: 'ReactionEvent',
      source: 'user',
      timestamp: '2026-11-07T00:00:00Z',
      target_event_id: 'm1',
      emoji: 'heart',
      removed: false,
    };
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify(saved), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    const event = await client.react('conv-1', 'heart', { targetEventId: 'm1', removed: true });
    await client.react('conv-1', '+1');

    expect(isReactionEvent(event)).toBe(true);
    expect(isReactionEvent({ ...saved, kind: 'MessageEvent' })).toBe(false);
    const fetchMock = global.fetch as Mock;
    expect(fetchMock.mock.calls[0][0]).toBe(
      'http://example.com/api/conversations/conv-1/reactions'
    );
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toEqual({
      emoji: 'heart',
      target_event_id: 'm1',
      removed: true,
    });
    expect(JSON.parse(fetchMock.mock.calls[1][1].body)).toEqual({ emoji: '+1' });
  });

  it('ConversationClient answers an ask_user question', async () => {
    const saved = {
      id: 'a1',
      timestamp: '2026-11-14T00:00:00',
      source: 'user',
      kind: 'AskUserAnswerEvent',
      ask_id: 'q1',
      option_index: 1,
      option_label: 'SQLite',
      text: null,
    };
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify(saved), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    const event = await client.answerAskUser('conv-1', 'q1', { optionIndex: 1 });
    await client.answerAskUser('conv-1', 'q1', { text: 'Neither' });

    expect(isAskUserAnswerEvent(event)).toBe(true);
    const fetchMock = global.fetch as Mock;
    expect(fetchMock.mock.calls[0][0]).toBe(
      'http://example.com/api/conversations/conv-1/ask_user/answer'
    );
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toEqual({
      ask_id: 'q1',
      option_index: 1,
    });
    expect(JSON.parse(fetchMock.mock.calls[1][1].body)).toEqual({
      ask_id: 'q1',
      text: 'Neither',
    });
  });

  it('SettingsClient fetches and updates settings and secrets', async () => {
    const responses = [
      { agent_settings: { llm_model: 'gpt-4o' }, conversation_settings: {} },
      { agent_settings: {}, conversation_settings: { max_iterations: 50 } },
      { secrets: [{ name: 'TOKEN', description: 'token' }] },
      { name: 'TOKEN', description: 'token' },
      'plain-secret',
      { deleted: true },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      const isText = typeof body === 'string';
      return Promise.resolve(
        new Response(isText ? body : JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': isText ? 'text/plain' : 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new SettingsClient({ host: 'http://example.com' });
    await client.getSettings({ exposeSecrets: 'encrypted' });
    await client.updateSettings({ conversation_settings_diff: { max_iterations: 50 } });
    await client.listSecrets({ agentProfileId: 'profile-id' });
    await client.upsertSecret({ name: 'TOKEN', value: 'secret', description: 'token' });
    await expect(client.getSecret('TOKEN')).resolves.toBe('plain-secret');
    await client.deleteSecret('TOKEN/with slash');

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/settings',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ 'X-Expose-Secrets': 'encrypted' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/settings',
      expect.objectContaining({
        method: 'PATCH',
        body: JSON.stringify({ conversation_settings_diff: { max_iterations: 50 } }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/settings/secrets?agent_profile_id=profile-id',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/settings/secrets',
      expect.objectContaining({ method: 'PUT' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/settings/secrets/TOKEN',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      6,
      'http://example.com/api/settings/secrets/TOKEN%2Fwith%20slash',
      expect.objectContaining({ method: 'DELETE' })
    );
  });

  it('FileClient wraps file browsing and download endpoints', async () => {
    const binary = new TextEncoder().encode('hello').buffer;
    global.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ home: '/workspace' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({ items: [{ name: 'src', path: '/workspace/src' }], next_page_id: null }),
          {
            status: 200,
            headers: { 'content-type': 'application/json' },
          }
        )
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ success: true }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(new Response(binary, { status: 200 }))
      .mockResolvedValueOnce(new Response(new Blob(['trajectory']), { status: 200 }));

    const client = new FileClient({ host: 'http://example.com' });
    await expect(client.getHome()).resolves.toEqual({ home: '/workspace' });
    await client.searchSubdirectories('/workspace', { limit: 10, pageId: 'p1' });
    await expect(client.uploadTextFile('hello', '/workspace/hello.txt')).resolves.toEqual({
      success: true,
    });
    await expect(client.downloadTextFile('/workspace/README.md')).resolves.toBe('hello');
    await expect(client.downloadTrajectory('conv 1')).resolves.toBeInstanceOf(Blob);

    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/file/search_subdirs?path=%2Fworkspace&page_id=p1&limit=10',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/file/upload?path=%2Fworkspace%2Fhello.txt',
      expect.objectContaining({ method: 'POST', body: expect.any(FormData) })
    );
    const uploadInit = (global.fetch as Mock).mock.calls[2][1];
    expect(uploadInit.headers['Content-Type']).toBeUndefined();
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/file/download?path=%2Fworkspace%2FREADME.md',
      expect.objectContaining({ method: 'GET', cache: 'no-store' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/file/download-trajectory/conv%201',
      expect.objectContaining({ method: 'GET' })
    );
    for (const index of [0, 1, 2, 4]) {
      expect((global.fetch as Mock).mock.calls[index][1].cache).toBeUndefined();
    }
  });

  it('FileClient forwards includeHidden to the home and search_subdirs endpoints', async () => {
    global.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ home: '/workspace' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ items: [], next_page_id: null }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );

    const client = new FileClient({ host: 'http://example.com' });
    await expect(client.getHome({ includeHidden: true })).resolves.toEqual({
      home: '/workspace',
    });
    await client.searchSubdirectories('/workspace', { includeHidden: true });

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/file/home?include_hidden=true',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/file/search_subdirs?path=%2Fworkspace&include_hidden=true',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('FileClient omits include_hidden when includeHidden is not set', async () => {
    global.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ home: '/workspace' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ items: [], next_page_id: null }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );

    const client = new FileClient({ host: 'http://example.com' });
    await client.getHome();
    await client.searchSubdirectories('/workspace');

    expect((global.fetch as Mock).mock.calls[0][0]).toBe('http://example.com/api/file/home');
    expect((global.fetch as Mock).mock.calls[1][0]).toBe(
      'http://example.com/api/file/search_subdirs?path=%2Fworkspace'
    );
  });

  it('ConversationClient wraps agent-canvas conversation endpoints', async () => {
    global.fetch = vi.fn().mockImplementation(() =>
      Promise.resolve(
        new Response(JSON.stringify({ success: true, response: 'ok' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      )
    ) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await client.sendEvent('c1', { role: 'user', content: [] }, { run: true });
    await client.pauseConversation('c1');
    await client.interruptConversation('c1');
    await client.runConversation('c1');
    await client.askAgent('c1', 'status?');
    await client.respondToConfirmation('c1', { accept: true });
    await client.deleteConversation('c1');
    await client.updateConversation('c1', { title: 'New title' });
    await client.getRuntime('c1');
    await client.reprovisionRuntime('c1');

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/conversations/c1/events',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ role: 'user', content: [], run: true }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/conversations/c1/interrupt',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/conversations/c1/ask_agent',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ question: 'status?' }) })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      6,
      'http://example.com/api/conversations/c1/events/respond_to_confirmation',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ accept: true }) })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      8,
      'http://example.com/api/conversations/c1',
      expect.objectContaining({ method: 'PATCH', body: JSON.stringify({ title: 'New title' }) })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      9,
      'http://example.com/api/conversations/c1',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      10,
      'http://example.com/api/conversations/c1/runtime',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      11,
      'http://example.com/api/conversations/c1/runtime/reprovision',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
    );
  });

  it('ConversationClient wraps SDK v1.23.0 conversation endpoints', async () => {
    const event = {
      id: 'event-1',
      kind: 'MessageEvent',
      timestamp: '2026-05-23T12:00:00Z',
      source: 'agent',
    };
    const responses = [
      2,
      { items: [event], next_page_id: null },
      event,
      4,
      { response: 'done' },
      { success: true },
      { success: true },
      { success: true },
      { success: true },
      { id: 'fork-1' },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new ConversationClient({ host: 'http://example.com' });
    await expect(
      client.countConversations({ status: ConversationExecutionStatus.IDLE })
    ).resolves.toBe(2);
    await expect(client.searchEvents('c1', { kind: 'MessageEvent', limit: 5 })).resolves.toEqual({
      items: [event],
      next_page_id: null,
    });
    await expect(client.getEvent('c1', 'event-1')).resolves.toEqual(event);
    await expect(client.getEventCount('c1', { source: 'agent' })).resolves.toBe(4);
    await expect(client.getAgentFinalResponse('c1')).resolves.toEqual({ response: 'done' });
    await client.setConfirmationPolicy('c1', { kind: 'NeverConfirm' });
    await client.condenseConversation('c1');
    await client.setSecurityAnalyzer('c1', { kind: 'LLMSecurityAnalyzer' });
    await client.updateSecrets('c1', {
      secrets: { TOKEN: { kind: 'StaticSecret', value: 'secret' } },
    });
    await client.forkConversation('c1', { title: 'Fork' }, { includeSkills: true });

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/api/conversations/count?status=idle',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/conversations/c1/events/search?kind=MessageEvent&limit=5',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      5,
      'http://example.com/api/conversations/c1/agent_final_response',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      6,
      'http://example.com/api/conversations/c1/confirmation_policy',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ policy: { kind: 'NeverConfirm' } }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      8,
      'http://example.com/api/conversations/c1/security_analyzer',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ security_analyzer: { kind: 'LLMSecurityAnalyzer' } }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      10,
      'http://example.com/api/conversations/c1/fork?include_skills=true',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ title: 'Fork' }) })
    );
  });

  describe('ConversationClient goal endpoints (error paths)', () => {
    function mockErrorResponse(status: number, statusText: string, detail: string): void {
      global.fetch = vi.fn(
        async () =>
          new Response(JSON.stringify({ detail }), {
            status,
            statusText,
            headers: { 'content-type': 'application/json' },
          })
      ) as typeof fetch;
    }

    it('startGoal posts the objective and rejects with HttpError 409 when a run is already active', async () => {
      mockErrorResponse(409, 'Conflict', 'Conversation run or goal loop already running.');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client
        .startGoal('c1', { objective: 'Audit the repo', max_iterations: 3 })
        .catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(409);
      // The failure must still have targeted the right route, method, and body
      // so a 409 is attributable to server state, not a client contract bug.
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/conversations/c1/goal',
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({ objective: 'Audit the repo', max_iterations: 3 }),
        })
      );
    });

    it('startGoal rejects with HttpError 400 when the objective is invalid', async () => {
      mockErrorResponse(400, 'Bad Request', 'Goal objective must not be empty.');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client.startGoal('c1', { objective: '' }).catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(400);
      // max_iterations is omitted from the wire body when not supplied so the
      // server applies its own default.
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/conversations/c1/goal',
        expect.objectContaining({ method: 'POST', body: JSON.stringify({ objective: '' }) })
      );
    });

    it('startGoal rejects with HttpError 404 for an unknown conversation', async () => {
      mockErrorResponse(404, 'Not Found', 'Item not found');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client
        .startGoal('does-not-exist', { objective: 'Audit the repo' })
        .catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(404);
    });

    it('resumeGoal posts an empty body and rejects with HttpError 400 when there is no resumable goal', async () => {
      mockErrorResponse(400, 'Bad Request', 'no_resumable_goal');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client.resumeGoal('c1').catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(400);
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/conversations/c1/goal/resume',
        expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
      );
    });

    it('resumeGoal rejects with HttpError 409 when a run or goal loop is already active', async () => {
      mockErrorResponse(409, 'Conflict', 'Conversation run or goal loop already running.');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client.resumeGoal('c1').catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(409);
    });

    it('stopGoal posts an empty body and rejects with HttpError 404 for an unknown conversation', async () => {
      mockErrorResponse(404, 'Not Found', 'Item not found');
      const client = new ConversationClient({ host: 'http://example.com' });

      const error = await client.stopGoal('does-not-exist').catch((e: unknown) => e);

      expect(error).toBeInstanceOf(HttpError);
      expect((error as HttpError).status).toBe(404);
      expect(global.fetch).toHaveBeenCalledWith(
        'http://example.com/api/conversations/does-not-exist/goal/stop',
        expect.objectContaining({ method: 'POST', body: JSON.stringify({}) })
      );
    });
  });

  it('Hooks and MCP clients wrap SDK v1.23.0 endpoints', async () => {
    const serverInfo = { version: '1.23.0', uptime: 1, idle_time: 0 };
    const responses = [
      serverInfo,
      { hook_config: null },
      serverInfo,
      { ok: true, tools: ['ping'] },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const options = { host: 'http://example.com', apiKey: 'secret' };
    await expect(
      new HooksClient(options).loadHooks({ project_dir: '/workspace' })
    ).resolves.toEqual({
      hook_config: null,
    });
    await expect(
      new MCPClient(options).testServer({
        server: { type: 'stdio', command: 'node', args: ['server.js'] },
        timeout: 10,
      })
    ).resolves.toEqual({ ok: true, tools: ['ping'] });

    expect(global.fetch).toHaveBeenNthCalledWith(
      1,
      'http://example.com/server_info',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/hooks',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({ project_dir: '/workspace' }),
        headers: expect.objectContaining({ 'X-Session-API-Key': 'secret' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/mcp/test',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({
          server: { type: 'stdio', command: 'node', args: ['server.js'] },
          timeout: 10,
        }),
      })
    );
  });

  it('new SDK v1.23.0 clients throw AgentServerVersionError for old servers', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ version: '1.22.1', uptime: 1, idle_time: 0 }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    ) as typeof fetch;

    await expect(
      new MCPClient({ host: 'http://example.com' }).testServer({
        server: { type: 'stdio', command: 'node' },
      })
    ).rejects.toMatchObject({
      code: 'AGENT_SERVER_VERSION_TOO_OLD',
      feature: 'mcp-test',
      requiredVersion: '1.23.0',
      actualVersion: '1.22.1',
    });

    expect(global.fetch).toHaveBeenCalledTimes(1);
  });

  it('MCPClient wraps MCP OAuth probe endpoints', async () => {
    const responses = [
      { version: '1.31.0', uptime: 1, idle_time: 0 },
      {
        ok: true,
        job_id: 'job-1',
        authorization_url: 'https://auth.example/authorize',
      },
      {
        ok: true,
        status: 'authorizing',
        job_id: 'job-1',
        authorization_url: 'https://auth.example/authorize',
        callback_ready: true,
      },
      {
        ok: true,
        status: 'succeeded',
        job_id: 'job-1',
        tools: ['search_mail'],
        oauth_state: {
          tokens: { access_token: 'gAAAAencrypted-access-token' },
          token_expires_at: 12345,
        },
      },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift();
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const client = new MCPClient({ host: 'http://example.com', apiKey: 'secret' });
    const request = {
      name: 'superhuman-mail',
      server: {
        type: 'http' as const,
        url: 'https://mcp.mail.superhuman.com/mcp',
        auth: {
          strategy: 'oauth2' as const,
          authentication: { type: 'oauth' as const, client_auth_method: 'none' as const },
        },
      },
      timeout: 120,
    };

    await expect(client.startOAuth(request)).resolves.toMatchObject({
      ok: true,
      job_id: 'job-1',
      authorization_url: 'https://auth.example/authorize',
    });
    await expect(client.getOAuthStatus('job/1')).resolves.toMatchObject({
      status: 'authorizing',
      callback_ready: true,
    });
    await expect(
      client.submitOAuthCallback('job/1', {
        callback_url: 'http://localhost:1234/callback?code=abc&state=xyz',
      })
    ).resolves.toMatchObject({
      status: 'succeeded',
      oauth_state: {
        tokens: { access_token: 'gAAAAencrypted-access-token' },
      },
    });

    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/mcp/oauth/start',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify(request),
        headers: expect.objectContaining({ 'X-Session-API-Key': 'secret' }),
      })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      3,
      'http://example.com/api/mcp/oauth/status/job%2F1',
      expect.objectContaining({ method: 'GET' })
    );
    expect(global.fetch).toHaveBeenNthCalledWith(
      4,
      'http://example.com/api/mcp/oauth/callback/job%2F1',
      expect.objectContaining({
        method: 'POST',
        body: JSON.stringify({
          callback_url: 'http://localhost:1234/callback?code=abc&state=xyz',
        }),
      })
    );
  });

  it('Shared client wraps app endpoints', async () => {
    const responses = [
      [{ id: 'shared-1', created_by_user_id: null, selected_repository: null }],
      { items: [], next_page_id: null },
    ];
    global.fetch = vi.fn().mockImplementation(() => {
      const body = responses.shift() ?? { success: true };
      return Promise.resolve(
        new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      );
    }) as typeof fetch;

    const options = { host: 'http://example.com' };
    await new SharedClient(options).getSharedConversation('shared-1');
    await new SharedClient(options).searchSharedEvents({ conversationId: 'shared-1', limit: 50 });

    expect(global.fetch).toHaveBeenNthCalledWith(
      2,
      'http://example.com/api/shared-events/search?conversation_id=shared-1&limit=50',
      expect.objectContaining({ method: 'GET' })
    );
  });

  it('BashClient.batchGetEvents GETs the batch endpoint with the event ids in the body', async () => {
    const events = [{ id: 'e1', kind: 'BashOutput', timestamp: '2026-05-23T12:00:00Z' }, null];
    const { captured } = mockNodeHttpRequest(JSON.stringify(events));

    const client = new BashClient({ host: 'http://example.com' });
    const result = await client.batchGetEvents(['e1', 'missing']);

    expect(result).toHaveLength(2);
    expect(result[0]?.id).toBe('e1');
    expect(result[1]).toBeNull();
    expect(captured.options?.method).toBe('GET');
    expect(captured.url?.toString()).toBe('http://example.com/api/bash/bash_events/');
    expect(JSON.parse(captured.body ?? 'null')).toEqual(['e1', 'missing']);
  });

  it('GitClient searches provider repositories', async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          items: [
            {
              id: '123',
              full_name: 'OpenHands/software-agent-sdk',
              git_provider: 'github',
              is_public: true,
              stargazers_count: 7,
              pushed_at: '2026-09-29T12:00:00Z',
              main_branch: 'main',
            },
          ],
          next_page_id: '2',
          missing_token: false,
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
    ) as typeof fetch;

    const client = new GitClient({ host: 'http://example.com', apiKey: 'secret' });
    const result = await client.searchRepositories({
      provider: 'github',
      query: 'OpenHands',
      limit: 30,
      pageId: '1',
    });

    expect(result.items[0].full_name).toBe('OpenHands/software-agent-sdk');
    expect(result.next_page_id).toBe('2');
    expect(global.fetch).toHaveBeenCalledWith(
      'http://example.com/api/git/repositories/search?provider=github&query=OpenHands&limit=30&page_id=1',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({
          'X-Session-API-Key': 'secret',
        }),
      })
    );
  });
});
